package com.soporte.apisopo.soporte.controller;

import com.soporte.apisopo.soporte.model.Opinion;
import com.soporte.apisopo.soporte.service.OpinionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/soporte")
@CrossOrigin(origins = "*")
public class OpinionController {
    @Autowired
    private OpinionService service;

    @GetMapping
    public List<Opinion> getAll() {
        return service.getAllOpinions();
    }

    @GetMapping("/{id}")
    public Optional<Opinion> getById(@PathVariable Long id) {
        return service.getOpinionById(id);
    }

    @PostMapping
    public Opinion create(@RequestBody Opinion opinion) {
        return service.saveOpinion(opinion);
    }

    @PutMapping("/{id}")
    public Opinion update(@PathVariable Long id, @RequestBody Opinion opinion) {
        opinion.setId(id);
        return service.saveOpinion(opinion);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.deleteOpinion(id);
    }
}