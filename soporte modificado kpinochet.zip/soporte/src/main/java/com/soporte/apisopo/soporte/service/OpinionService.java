package com.soporte.apisopo.soporte.service;

import com.soporte.apisopo.soporte.model.Opinion;
import com.soporte.apisopo.soporte.repository.OpinionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OpinionService {
    @Autowired
    private OpinionRepository repository;

    public List<Opinion> getAllOpinions() {
        return repository.findAll();
    }

    public Optional<Opinion> getOpinionById(Long id) {
        return repository.findById(id);
    }

    public Opinion saveOpinion(Opinion opinion) {
        return repository.save(opinion);
    }

    public void deleteOpinion(Long id) {
        repository.deleteById(id);
    }
}