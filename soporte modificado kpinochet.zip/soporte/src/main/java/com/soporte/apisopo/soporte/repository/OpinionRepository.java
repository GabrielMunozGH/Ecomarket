package com.soporte.apisopo.soporte.repository;

import com.soporte.apisopo.soporte.model.Opinion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OpinionRepository extends JpaRepository<Opinion, Long> {
}